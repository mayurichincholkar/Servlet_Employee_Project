import java.io.*;  
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;  
import java.sql.*;  
 
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet  {    
	
     public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException 
      {  
         PrintWriter out = res.getWriter();  
         res.setContentType("text/html");  
         out.println("<html><body>");  
         try 
         {  
        	 Class.forName("com.mysql.jdbc.Driver");
 			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ServletDb","root","");
 			  
 			 PreparedStatement stmt = con.prepareStatement("insert into employee(name,email,salary) values('Emp2','Emp2@gmail.com','12000')"); 
             
             stmt.executeUpdate();
             out.println("Added Successfully!"); 
             con.close();  
            }  
             catch (Exception e) 
            {  
             out.println("error");  
         }  
     }  
 }  
