import java.io.*;  
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;  
import java.sql.*;  
 
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet  {    
	
     public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException 
      {  
         PrintWriter out = res.getWriter();  
         res.setContentType("text/html");  
         out.println("<html><body>");  
         try 
         {  
        	 Class.forName("com.mysql.jdbc.Driver");
 			 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ServletDb","root","");
 			 
 			 PreparedStatement st = con.prepareStatement("UPDATE employee SET name = 'Emp3', email = 'emp3@gmail.com', salary = '20000' WHERE name = 'Emp2' ");
   
              
             st.executeUpdate();
             
  
             out.println("updated successfully!");
             st.close();
             con.close();
   
                    } catch (Exception e) {  
             out.println("error");  
         }  
     }  
 }  